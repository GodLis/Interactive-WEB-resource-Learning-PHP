</div>

<div class="panel-footer coll-md-12 text-info center-block text-center" id="footer">
    Dev by <a href="https://github.com/GodLis">Olechka Brajko</a> 2017
</div>

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>

</html>