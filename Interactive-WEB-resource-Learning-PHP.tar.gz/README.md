**Interactive Web-resource for study Web-programming. 
"The direction of PHP"**