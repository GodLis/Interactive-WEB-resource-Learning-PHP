<?php include_once("header.php");
    session_destroy();
?>

    <div></div>

<?php include_once("footer.php");
