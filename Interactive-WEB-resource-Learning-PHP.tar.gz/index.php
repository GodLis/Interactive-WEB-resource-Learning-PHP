<?php include_once("header.php");
    session_destroy();
?>

    <div>jdfsbh </div>

<?php include_once("footer.php");
